# ARL-MACR
Code for Asynchronous Reinforcement Learning for Multi-Agent Cooperation-Based Reasoning

![ARL-MACR Framework](Figs/MainFig.png)

ARL-MACR Framework is based on [verl](https://github.com/volcengine/verl.git). 
